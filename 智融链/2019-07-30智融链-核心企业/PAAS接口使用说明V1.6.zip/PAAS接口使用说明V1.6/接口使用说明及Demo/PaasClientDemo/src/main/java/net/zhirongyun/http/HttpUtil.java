package net.zhirongyun.http;


import com.alibaba.fastjson.JSONObject;
import net.zhirongyun.core.SdkInitializer;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static net.zhirongyun.utils.CommonUtil.copyToByteArray;

/**
 * Created by song on 24/08/2017.
 */
public class HttpUtil
{
    public static JSONObject sendGet(String uri, Map<String, Object> params, Map<String, String> headers) throws Exception
    {
        String url = SdkInitializer.getInitParams().url + uri;
        if (params != null)
        {
            StringBuilder sb = new StringBuilder(url);
            sb.append("?");
            for (Map.Entry<String, Object> entry : params.entrySet())
            {
                sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
            }

            url = sb.toString();
        }

        CloseableHttpClient client = createSslClient();
        HttpGet httpGet = new HttpGet(url);
        if (headers != null)
        {
            for (Map.Entry<String, String> entry : headers.entrySet())
            {
                httpGet.setHeader(entry.getKey(), entry.getValue());
            }
        }
        String data;
        CloseableHttpResponse execute = client.execute(httpGet);
        //StatusLine statusLine = execute.getStatusLine();
        data = EntityUtils.toString(execute.getEntity(), "utf-8");

      /*  if (statusLine.getStatusCode() == 200)
        {
        }
        else
        {
            throw new Exception("发送请求失败：" + String.valueOf(statusLine.getStatusCode()) + statusLine.getReasonPhrase());
        }*/
        return JSONObject.parseObject(data);
    }


    public static JSONObject postMultipart(String url, Map<String, Object> param, Map<String, InputStream> multiPart, Map<String, String> headers)
    {
        return sendPost(url, buildMultiPartEntity(param, multiPart), null, headers);
    }

    public static JSONObject postJson(String url, String json, Map<String, String> headers)
    {
        return sendPost(url, buildJsonEntity(json), "application/json;charset=UTF-8", headers);
    }

    public static JSONObject postForm(String url, Map<String, Object> param, Map<String, String> headers)
    {
        return sendPost(url, buildUrlEncodedEntity(param), "application/x-www-form-urlencoded", headers);
    }

    private static HttpEntity buildMultiPartEntity(Map<String, Object> param, Map<String, InputStream> multiPart)
    {
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();

        if (param != null)
        {
            for (Map.Entry<String, Object> entry : param.entrySet())
            {
                builder.addPart(entry.getKey(), new StringBody(entry.getValue().toString(), ContentType.TEXT_PLAIN));
            }
        }


        if (multiPart != null)
        {
            for (Map.Entry<String, InputStream> entry : multiPart.entrySet())
            {
                try
                {
                    byte[] data = copyToByteArray(entry.getValue());
                    builder.addPart(entry.getKey(), new ByteArrayBody(data, "file")).build();
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }

        return builder.build();

    }


    private static HttpEntity buildUrlEncodedEntity(Map<String, Object> param)
    {
        List<NameValuePair> params = new ArrayList<>();
        if (param != null)
        {
            for (Map.Entry<String, Object> entry : param.entrySet())
            {
                if (entry.getValue() != null)
                {
                    String val = entry.getValue().toString();
                    params.add(new BasicNameValuePair(entry.getKey(), val));
                }
            }
        }

        try
        {
            HttpEntity paramEntity = new UrlEncodedFormEntity(params, "UTF-8");
            return paramEntity;
        } catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    private static HttpEntity buildJsonEntity(String json)
    {
        try
        {
            return new StringEntity(json, "UTF-8");
        } catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }

        return null;
    }

    private static JSONObject sendPost(String uri, HttpEntity httpEntity, String contentType, Map<String, String> headers)
    {
        String url = SdkInitializer.getInitParams().url + uri;


        try
        {
            //返回body
            String data = "";
            //CloseableHttpClient httpClient = HttpClients.createDefault();
            CloseableHttpClient httpClient = createSslClient();

            HttpPost httpPost = new HttpPost(url);
            httpPost.setConfig(buildRequestConfig());

            httpPost.setEntity(httpEntity);
            if (contentType != null)
            {
                httpPost.setHeader("Content-type", contentType);
            }

            //5、设置header信息
            httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");

            if (headers != null)
            {
                for (Map.Entry<String, String> entry : headers.entrySet())
                {
                    httpPost.setHeader(entry.getKey(), entry.getValue());
                }
            }

            //6、设置编码
            //7、执行post请求操作，并拿到结果（同步阻塞）
            CloseableHttpResponse httpResponse;

            httpResponse = httpClient.execute(httpPost);
            //获取结果实体
            HttpEntity entity = httpResponse.getEntity();
            if (entity != null)
            {
                //按指定编码转换结果实体为String类型
                data = EntityUtils.toString(entity, "utf-8");
            }
            EntityUtils.consume(entity);
            //释放链接
            httpResponse.close();
            return JSONObject.parseObject(data);
        } catch (Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static RequestConfig buildRequestConfig()
    {
        //设置请求和传输超时时间
        RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(SdkInitializer.getInitParams().readTimeout)
                .setConnectTimeout(SdkInitializer.getInitParams().connectTimeout).build();
        return requestConfig;
    }

    private static CloseableHttpClient createSslClient()
    {
        Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
                .register("http", PlainConnectionSocketFactory.INSTANCE)
                .register("https", new SSLConnectionSocketFactory(SdkInitializer.getSslSocketFactory(), new AllowAllHostnameVerifier()))
                .build();
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
        HttpClients.custom().setConnectionManager(connManager);
        CloseableHttpClient client = HttpClients.custom().setConnectionManager(connManager).build();
        return client;
    }

}