package net.zhirongyun.core;

import net.zhirongyun.utils.CommonUtil;
import org.slf4j.Logger;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.SecureRandom;

import static net.zhirongyun.utils.SystemConst.*;

/**
 * Created by song on 19-4-12.
 *
 * @author song
 */
public final class SdkInitializer
{
    public static Logger logger;

    private static InitParams initParams;
    private static SSLSocketFactory sslSocketFactory;

    public static void init(InitParams params, Logger logger) throws GeneralSecurityException, IOException
    {
        SdkInitializer.logger = logger;
        initParams = params;
        initSSL(params.jksPath, params.jksPassword.toCharArray(), params.jksPath, params.jksPassword.toCharArray());

        if (!initParams.url.endsWith("/"))
        {
            initParams.url += "/";
        }
    }

    public static void initSSL(String keyStorePath, char[] keyStorePassword, String trustStorePath, char[] trustStorePassword) throws GeneralSecurityException,
            IOException
    {
        KeyManagerFactory keyManagerFactory = null;
        KeyStore keyStore = null;
        if (CommonUtil.isEmpty(DEFAULT_KEY_PROVIDER))
        {
            keyManagerFactory = KeyManagerFactory.getInstance(DEFAULT_KEY_ALGORITHM);
            if (CommonUtil.isNotEmpty(DEFAULT_KEY_STORE_TYPE))
            {
                keyStore = KeyStore.getInstance(DEFAULT_KEY_STORE_TYPE);
            }
        }
        else
        {
            keyManagerFactory = KeyManagerFactory.getInstance(DEFAULT_KEY_ALGORITHM, DEFAULT_KEY_PROVIDER);
            if (CommonUtil.isNotEmpty(DEFAULT_KEY_STORE_TYPE))
            {
                keyStore = KeyStore.getInstance(DEFAULT_KEY_STORE_TYPE, DEFAULT_KEY_PROVIDER);
            }
        }
        if (CommonUtil.isEmpty(keyStorePath))
        {
            keyManagerFactory.init(keyStore, keyStorePassword);
        }
        else
        {
            FileInputStream fileInputStream = null;
            try
            {
                fileInputStream = new FileInputStream(keyStorePath);
                keyStore.load(fileInputStream, keyStorePassword);
                keyManagerFactory.init(keyStore, keyStorePassword);
            } finally
            {
                if (fileInputStream != null)
                {
                    fileInputStream.close();
                }
            }
        }

        TrustManagerFactory trustManagerFactory = null;
        KeyStore trustStore = null;
        if (CommonUtil.isEmpty(DEFAULT_TRUST_PROVIDER))
        {
            trustManagerFactory = TrustManagerFactory.getInstance(DEFAULT_TRUST_ALGORITHM);
            if (CommonUtil.isNotEmpty(DEFAULT_TRUST_STORE_TYPE))
            {
                trustStore = KeyStore.getInstance(DEFAULT_TRUST_STORE_TYPE);
            }
        }
        else
        {
            trustManagerFactory = TrustManagerFactory.getInstance(DEFAULT_TRUST_ALGORITHM, DEFAULT_TRUST_PROVIDER);
            if (CommonUtil.isNotEmpty(DEFAULT_TRUST_STORE_TYPE))
            {
                trustStore = KeyStore.getInstance(DEFAULT_TRUST_STORE_TYPE, DEFAULT_TRUST_PROVIDER);
            }
        }
        if (CommonUtil.isEmpty(trustStorePath))
        {
            trustManagerFactory.init(trustStore);
        }
        else
        {
            FileInputStream fileInputStream = null;
            try
            {
                fileInputStream = new FileInputStream(trustStorePath);
                trustStore.load(fileInputStream, trustStorePassword);
                trustManagerFactory.init(trustStore);
                fileInputStream.close();
            } finally
            {
                if (fileInputStream != null)
                {
                    fileInputStream.close();
                }
            }
        }

        SSLContext sslContext = null;
        if (CommonUtil.isEmpty(DEFAULT_SSL_PROVIDER))
        {
            sslContext = SSLContext.getInstance(DEFAULT_SSL_PROTOCOL);
        }
        else
        {
            sslContext = SSLContext.getInstance(DEFAULT_SSL_PROTOCOL, DEFAULT_SSL_PROVIDER);
        }
        sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), new SecureRandom());
        sslSocketFactory = sslContext.getSocketFactory();
    }


    public static SSLSocketFactory getSslSocketFactory()
    {
        return sslSocketFactory;
    }

    public static InitParams getInitParams()
    {
        return initParams;
    }
}
