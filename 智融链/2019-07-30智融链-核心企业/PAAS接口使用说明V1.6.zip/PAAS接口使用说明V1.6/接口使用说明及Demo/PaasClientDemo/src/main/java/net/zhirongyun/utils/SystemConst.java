package net.zhirongyun.utils;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.TrustManagerFactory;
import java.security.KeyStore;
import java.util.Arrays;
import java.util.Locale;

public class SystemConst
{
    public static final String DEFAULT_CHARSET = "UTF-8";
    public static final Locale DEFAULT_LOCALE = Locale.CHINA;

    public static final int DEFAULT_BUFFER_SIZE = 2048;
    public static final int DEFAULT_CONNECT_TIMEOUT = 3000;
    public static final int DEFAULT_READ_TIMEOUT = 30000;

    public static final String DEFAULT_KEY_PROVIDER = null;
    public static final String DEFAULT_TRUST_PROVIDER = null;
    public static final String DEFAULT_SSL_PROVIDER = null;

    public static final String DEFAULT_SSL_PROTOCOL = "TLSv1.1";
    public static final String DEFAULT_KEY_ALGORITHM = KeyManagerFactory.getDefaultAlgorithm();
    public static final String DEFAULT_KEY_STORE_TYPE = KeyStore.getDefaultType();
    public static final String DEFAULT_TRUST_ALGORITHM = TrustManagerFactory.getDefaultAlgorithm();
    public static final String DEFAULT_TRUST_STORE_TYPE = KeyStore.getDefaultType();

    public static final String DEFAULT_HTTP_USER_AGENT = "ZhirongyunTrustCli";
    public static final String DEFAULT_HTTP_CONNECTION = "close";
    public static final String DEFAULT_HTTP_CONTENT_TYPE = "text/plain";
    public static final String DEFAULT_HTTP_ACCEPT = "text/plain";

    private static final String[] SORT = { Locale.CHINA.toString() };
    static {
        Arrays.sort(SORT);
    }

    public static boolean isSupportedLocale(String locale) {
        return (Arrays.binarySearch(SORT, locale) >= 0);
    }
}
