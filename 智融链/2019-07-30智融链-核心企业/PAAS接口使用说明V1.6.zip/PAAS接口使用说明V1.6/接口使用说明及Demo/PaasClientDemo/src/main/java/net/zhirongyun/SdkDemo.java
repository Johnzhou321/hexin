package net.zhirongyun;

import com.alibaba.fastjson.JSONObject;
import net.zhirongyun.core.InitParams;
import net.zhirongyun.core.SdkInitializer;
import net.zhirongyun.http.HttpUtil;
import net.zhirongyun.utils.CommonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Encoder;

import java.io.*;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * ZhirongyunSDK Demo
 *
 * @author song
 * @since V1.0
 */
public class SdkDemo
{
    public static void main(String[] args) throws Exception
    {
        init();
        test();
    }


    /**
     * 初始化S
     *
     * @throws IOException
     * @throws GeneralSecurityException
     */
    private static void init() throws IOException, GeneralSecurityException
    {
        Properties initProps = new Properties();
        initProps.load(SdkDemo.class.getResourceAsStream("/init.properties"));
        String url = initProps.getProperty("url");
        int connectTimeout = Integer.parseInt(initProps.getProperty("connectTimeout"));
        int readTimeout = Integer.parseInt(initProps.getProperty("readTimeout"));
        String jksPath = initProps.getProperty("jksPath");
        String jksPassword = initProps.getProperty("jksPassword");
        String alias = initProps.getProperty("alias");
        String securityToken = initProps.getProperty("securityToken");
        String clientCode = initProps.getProperty("clientCode");

        InitParams initParams = new InitParams(url, connectTimeout, readTimeout, jksPath, jksPassword, alias, securityToken, clientCode);

        Logger logger = LoggerFactory.getLogger(SdkDemo.class);
        SdkInitializer.init(initParams, logger);
    }

    private static void test() throws Exception
    {
        Map headers = new HashMap();
        headers.put("Authorization", SdkInitializer.getInitParams().securityToken);
        headers.put("User-Agent", SdkInitializer.getInitParams().clientCode);

        Map params = new HashMap();


        JSONObject ret = HttpUtil.postForm("ping", params, headers);
        System.out.println(ret);
    }

}
