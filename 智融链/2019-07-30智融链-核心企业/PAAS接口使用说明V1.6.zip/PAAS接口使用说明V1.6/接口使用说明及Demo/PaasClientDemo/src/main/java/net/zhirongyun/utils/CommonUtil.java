package net.zhirongyun.utils;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CommonUtil
{
    public static boolean isEmpty(String str)
    {
        return (str == null || str.trim().length() == 0);
    }

    public static boolean isNotEmpty(String str)
    {
        return (str != null && str.trim().length() != 0);
    }

    public static boolean isEmpty(String[] strs)
    {
        return (strs == null || strs.length == 0);
    }

    public static boolean isNotEmpty(String[] strs)
    {
        return (strs != null && strs.length != 0);
    }

    public static <T> boolean isEmpty(List<T> list)
    {
        return (list == null || list.isEmpty());
    }

    public static <T> boolean isNotEmpty(List<T> list)
    {
        return (list != null && !list.isEmpty());
    }

    public static <K, V> boolean isEmpty(Map<K, V> map)
    {
        return (map == null || map.isEmpty());
    }

    public static <K, V> boolean isNotEmpty(Map<K, V> map)
    {
        return (map != null && !map.isEmpty());
    }

    public static <K, V> List<V> mapToList(Map<K, V> map)
    {
        List<V> list = new ArrayList<V>();
        list.addAll(map.values());
        return list;
    }

    public static int booleanToInt(Boolean bool)
    {
        return bool == null ? 0 : (bool ? 1 : 0);
    }

    public static boolean intToBoolean(Integer i)
    {
        return i == null ? false : (i != 0 ? true : false);
    }

    public static Number nvl(Number obj, Number value)
    {
        if (obj == null)
        {
            return value;
        }
        else
        {
            return obj;
        }
    }

    public static String nvl(String str, String value)
    {
        if (isEmpty(str))
        {
            return value;
        }
        else
        {
            return str;
        }
    }

    public static byte[] getBytes(String str)
    {
        try
        {
            return str.getBytes(SystemConst.DEFAULT_CHARSET);
        } catch (UnsupportedEncodingException e)
        {
            return null;
        }
    }

    public static String getString(byte[] bytes)
    {
        try
        {
            return new String(bytes, SystemConst.DEFAULT_CHARSET);
        } catch (UnsupportedEncodingException e)
        {
            return null;
        }
    }

    public static String toString(String[] strings)
    {
        if (strings == null)
            return "";
        int iMax = strings.length - 1;
        if (iMax == -1)
            return "";

        StringBuilder b = new StringBuilder();
        for (int i = 0; ; i++)
        {
            b.append(String.valueOf(strings[i]));
            if (i == iMax)
                return b.toString();
            b.append(";");
        }
    }

    public static String base64Encode(InputStream in) throws IOException
    {
        return new BASE64Encoder().encode(copyToByteArray(in));
    }

    public static byte[] base64Decode(String src) throws IOException
    {
        return new BASE64Decoder().decodeBuffer(src);
    }

    public static byte[] copyToByteArray(InputStream in) throws IOException {
        if (in == null) {
            return new byte[0];
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(4096);
        copy(in, out);
        return out.toByteArray();
    }

    public static int copy(InputStream in, OutputStream out) throws IOException
    {
        int byteCount = 0;
        byte[] buffer = new byte[4096];
        int bytesRead = -1;
        while ((bytesRead = in.read(buffer)) != -1)
        {
            out.write(buffer, 0, bytesRead);
            byteCount += bytesRead;
        }
        out.flush();
        return byteCount;
    }
}
