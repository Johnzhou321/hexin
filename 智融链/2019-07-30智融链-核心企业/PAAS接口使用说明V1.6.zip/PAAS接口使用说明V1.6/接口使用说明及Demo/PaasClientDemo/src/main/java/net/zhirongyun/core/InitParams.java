package net.zhirongyun.core;

/**
 * SDK初始化参数
 * Created by song on 19-4-12.
 *
 * @author song
 */
public class InitParams
{
    /**
     * 接口请求地址
     */
    public String url;

    /**
     * ConnectTimeout, 单位为milliseconds
     */
    public int connectTimeout;

    /**
     * ReadTimeout, 单位为milliseconds
     */
    public int readTimeout;



    /**
     * 证书文件路径
     */
    public String jksPath;

    /**
     * 证书密码
     */
    public String jksPassword;

    /**
     * alias
     */
    public String alias;

    /**
     * alias
     */
    public String clientCode;

    /**
     * token
     */
    public String securityToken;


    public InitParams()
    {
    }

    public InitParams(String url, int connectTimeout, int readTimeout, String jksPath, String jksPassword, String alias, String securityToken, String clientCode)
    {
        this.url = url;
        this.connectTimeout = connectTimeout;
        this.readTimeout = readTimeout;
        this.jksPath = jksPath;
        this.jksPassword = jksPassword;
        this.alias = alias;
        this.securityToken = securityToken;
        this.clientCode = clientCode;
    }
}
