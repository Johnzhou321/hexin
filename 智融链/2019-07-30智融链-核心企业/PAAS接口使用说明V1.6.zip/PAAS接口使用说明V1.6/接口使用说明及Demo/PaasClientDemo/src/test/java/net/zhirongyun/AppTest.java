package net.zhirongyun;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple SdkDemo.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
